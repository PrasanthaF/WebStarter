export class OldBook {
  bookTitle: string;
  year: number;
}